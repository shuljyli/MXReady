# MXReady remote verification safety

This archive runs only on a host controlled by you.

- Read `mxready.yml` and every project command before running it.
- Environment inspection uses the fixed commands listed in the manifest.
- Project commands run only after your explicit approval.
- The runner never uses `sudo`, installs packages, or changes GPU drivers.
- Commands use argument arrays with `shell=False` and bounded timeouts.
- Output is redacted and truncated, but review `result.json` before sharing it.
